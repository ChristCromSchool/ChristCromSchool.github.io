// app_admin/src/polyfills.ts
import '@angular/localize/init';

// ... rest of your polyfills
