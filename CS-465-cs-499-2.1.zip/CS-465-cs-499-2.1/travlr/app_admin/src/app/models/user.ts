// app_admin/src/app/models/user.ts
export class User {
  name: string = '';
  email: string = '';
  password: string = '';
  googleId?: string;
}
