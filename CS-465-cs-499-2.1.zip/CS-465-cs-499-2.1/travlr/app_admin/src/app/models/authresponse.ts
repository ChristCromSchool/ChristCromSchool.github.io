// app_admin/src/app/models/authresponse.ts
export class AuthResponse {
  token?: string;
  googleId?: string;
}